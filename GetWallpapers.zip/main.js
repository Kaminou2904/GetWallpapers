console.log('Hello World!');

const nav = document.querySelector(".navBar");

